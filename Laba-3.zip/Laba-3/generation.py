import math

def func(x):	
	return x**2 - 2*math.sin(x**2)

with open("input.txt", "w") as f:
	a = 0
	b = 6
	dx = 0.01

	f.write("x;y\n")
	while a <= b:
		line = str(round(a, 2))+";"+str(func(a))+"\n"
		f.write(line)
		a += dx
