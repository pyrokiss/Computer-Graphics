import plotly.graph_objs as go
import plotly

x_data = []
y_data = []

with open("input.txt", "r") as f:
	lines = f.readlines()
	for line in lines[1:]:
		str_data = line.replace("\n", "").split(";")
		x_data.append(str_data[0])
		y_data.append(str_data[1])

fig = go.Figure()
fig.add_trace(go.Scatter(x = x_data, y = y_data, mode = "lines"))
plotly.offline.plot(fig, "input_img")
